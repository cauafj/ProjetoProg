import "./home.css";
import { useState } from "react";
import warrior from "./warrior.png";

const initialHomesValue = {
  homes: [
    { name: "snakes", isBusy: false, color: "green" },
    { name: "dragons", isBusy: false, color: "red" },
    { name: "salamander", isBusy: false, color: "orange" },
    { name: "eagles", isBusy: false, color: "blue" },
  ],
};

const ButtonComponent = ({ name, isBusy, color, changeHome, homes }) => {
  const onChangeIsBusy = () => changeHome(name, homes);

  const buttonName = !isBusy
    ? `Change to ${name?.[0]?.toUpperCase() + name?.substring(1)}'s House`
    : `Changed to ${name?.[0]?.toUpperCase() + name?.substring(1)}'s House`;

  return (
    <button
      className={`button button-style-${color}`}
      onClick={onChangeIsBusy}
      disabled={isBusy}
    >
      <p className="button__name">{buttonName}</p>
    </button>
  );
};

const HomeCardComponent = ({ name, isBusy, color }) => {
  return (
    <div className={`home-card button-style-${color}`}>
      <p className="home-card__name">
        {name?.[0]?.toUpperCase() + name?.substring(1)}
      </p>
      <div className="home-card__circle">
        {isBusy ? (
          <img src={warrior} alt="" className="home-card__image" />
        ) : null}
      </div>
    </div>
  );
};

const HomeScreen = () => {
  const [homes, setHomes] = useState(initialHomesValue);

  const setHome = (name, actualHomesValue) => {
    const newHomesValue = actualHomesValue?.homes?.map((element) => {
      console.log(element.name);
      console.log(name);
      return element?.name === name
        ? { ...element, isBusy: true }
        : { ...element, isBusy: false };
    });

    console.log(newHomesValue);

    setHomes({ homes: newHomesValue });
  };

  return (
    <div className="home">
      <div className="home__select-home-buttons">
        {homes?.homes !== null
          ? homes?.homes?.map((element, index) => {
              return (
                <ButtonComponent
                  key={index}
                  name={element?.name}
                  isBusy={element?.isBusy}
                  color={element?.color}
                  changeHome={setHome}
                  homes={homes}
                />
              );
            })
          : null}
      </div>
      <div className="home__home-cards">
        {homes?.homes !== null
          ? homes?.homes?.map((element, index) => {
              return (
                <HomeCardComponent
                  key={index}
                  name={element?.name}
                  isBusy={element?.isBusy}
                  color={element?.color}
                />
              );
            })
          : null}
      </div>
    </div>
  );
};

export { HomeScreen };
