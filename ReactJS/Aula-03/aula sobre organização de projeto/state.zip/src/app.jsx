import "./app.css";
import { HomeScreen } from "./home.screen.jsx";

function App() {
  return (
    <div className="App">
      <HomeScreen />
    </div>
  );
}

export default App;
