import "./home.css";
import { useState } from "react";
import { ButtonComponent, HomeCardComponent } from "./../components";

const initialHomesValue = {
  homes: [
    { name: "snakes", isBusy: false, color: "green" },
    { name: "dragons", isBusy: false, color: "red" },
    { name: "salamander", isBusy: false, color: "orange" },
    { name: "eagles", isBusy: false, color: "blue" },
  ],
};

const HomeScreen = () => {
  const [homes, setHomes] = useState({ casa1: [], casa2: [] });

  const setHome = (name, actualHomesValue) => {
    const newHomesValue = actualHomesValue?.homes?.map((element) => {
      return element?.name === name
        ? { ...element, isBusy: true }
        : { ...element, isBusy: false };
    });

    setHomes({ homes: newHomesValue });
  };

  return (
    <div className="home">
      <div className="home__select-home-buttons">
        {homes?.homes !== null
          ? homes?.homes?.map((element, index) => {
              return (
                <ButtonComponent
                  key={index}
                  name={element?.name}
                  isBusy={element?.isBusy}
                  color={element?.color}
                  changeHome={setHome}
                  homes={homes}
                />
              );
            })
          : null}
      </div>
      <div className="home__home-cards">
        {homes?.homes !== null
          ? homes?.homes?.map((element, index) => {
              return (
                <HomeCardComponent
                  key={index}
                  name={element?.name}
                  isBusy={element?.isBusy}
                  color={element?.color}
                />
              );
            })
          : null}
      </div>
    </div>
  );
};

export { HomeScreen };
