import "./button.css";

const ButtonComponent = ({ name, isBusy, color, changeHome, homes }) => {
  const onChangeIsBusy = () => changeHome(name, homes);

  const buttonName = !isBusy
    ? `Change to ${name?.[0]?.toUpperCase() + name?.substring(1)}'s House`
    : `Changed to ${name?.[0]?.toUpperCase() + name?.substring(1)}'s House`;

  return (
    <button
      className={`button button-style-${color}`}
      onClick={onChangeIsBusy}
      disabled={isBusy}
    >
      <p className="button__name">{buttonName}</p>
    </button>
  );
};

export { ButtonComponent };
