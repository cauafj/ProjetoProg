import "./home-card.css";
import warrior from "./../../../assets/warrior.png";

const HomeCardComponent = ({ name, isBusy, color }) => {
  return (
    <div className={`home-card button-style-${color}`}>
      <p className="home-card__name">
        {name?.[0]?.toUpperCase() + name?.substring(1)}
      </p>
      <div className="home-card__circle">
        {isBusy ? (
          <img src={warrior} alt="warrior" className="home-card__image" />
        ) : null}
      </div>
    </div>
  );
};

export { HomeCardComponent };
