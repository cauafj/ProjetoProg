import "./app.css";
import { HomeScreen } from "./ui/screen/home.screen.jsx";

function App() {
  return (
    <div className="App">
      <HomeScreen />
    </div>
  );
}

export default App;
